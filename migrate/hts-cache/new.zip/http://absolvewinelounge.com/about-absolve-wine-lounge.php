



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<title>About Absolve Wine Lounge</title>
<meta name="keywords" content="About Absolve Wine Lounge" />
<meta name="description" content="About Absolve Wine Lounge" />
    <link href='http://fonts.googleapis.com/css?family=Alex+Brush' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Arbutus+Slab' rel='stylesheet' type='text/css'>
	<link href="css/style.css" rel="stylesheet" type="text/css" />
    <link href="css/nav-top.css" rel="stylesheet" type="text/css" />
    

	<script type="text/javascript" src="js/ie-hover-code.js"></script>
	<script type="text/javascript" src="js/prototype.js"></script>
    <script type="text/javascript" src="js/scriptaculous.js?load=effects,builder"></script>
    <style>
	#content-box{
	background:url(images/flourish2.jpg) top left no-repeat #FFFFFF;
	}
	
	</style>
      
</head>


<body>

	<div id="box">
		
		<div id="header">
		
			<a href="index.php"><img src="images/absolve-wine-lounge-logo.jpg" alt="Absolve Wine Lounge"/></a>
		
					
		</div>
				
		<div id="images-space"></div>
        
        <div id="navbar">
        	<div id="navbuttons">
					<ul id="nav-top">
						<li class="nav-top-tab"><a href="index.php">Home</a></li>

						<li class="nav-top-tab"><a href="houston-wine-bar-menu.php">Menu</a>
							<ul>
								<li><a href="houston-wine-bar-wine-menu.php">Wine</a></li>
								<li><a href="houston-wine-bar-happy-hour-menu.php">Happy Hour</a></li>
								<li><a href="houston-wine-bar-food-menu.php">Food</a></li>						
							</ul>
						</li>

						<li class="nav-top-tab"><a href="about-absolve-wine-lounge.php" class="selected">About Us</a></li>

						<li class="nav-top-tab"><a href="houston-wine-bar-events.php">Events</a></li>
                        
                        <li class="nav-top-tab"><a href="absolve-wine-lounge-photo-gallery.php">Gallery</a></li>
                        
                        <li class="nav-top-tab"><a href="houston-wine-bar-contact.php">Contact Us</a></li>
                        
					</ul>

				</div>
		</div>
		
      </div>  
        
        <div id="box2">
        
        
        
        
        <div id="content-box">
			
			
			
			
						
			
			
			<div id="content-wide">	
About Absolve Wine Lounge<br><br>Our Philosophy<br><br>Wine is a big deal, but it doesn't need to be a big deal.<br><br>There is no need to be intimidated by grapes in a glass. It's not that simple by all means, but we want you to feel like you can approach any glass or bottle of wine with confidence. Our staff is educated regularly on wine and we want to impart that knowledge upon you. We're constantly growing and evolving, and we want to feel comfortable with asking any questions. We want you to feel right at home and we are all just hanging our with an interesting bottle of wine.<br><br>The concept of what a wine bar can be isn't limited and we want to show you that you can have the aesthetic of a living room coupled with innovation and creativity with a nod to the whimsical.<br><br>To put it simply, wine is not solely one thing to everyone, why should we be?<br><br>The McCabe Family<br><br>Absolve Wine Lounge was founded by the McCabe family in the summer of 2009. Greg McCabe first entered the hospitality industry when opening Absolve. Greg worked previously in commercial real estate before finding Absolve's current location. He decided the neighborhood needed a bar within walking distance to appease the desire of those to drink and eat close to home. The first vision of Absolve started with the idea to create a boutique retail wine shop. After nine months of research and hard work, Greg opened the doors of Absolve Wine Lounge on New Year's Eve 2009.		

		<br style="clear:both;"/><br /><br />	

			

			</div>

		</div>

	


        

        </div>

        	<br style="clear:both;"/><br /><br />	

        <div id="box3">

            <div id="footer">

                

                

                

                    <a href="index.php">Home</a> 				

                        <a href="houston-wine-bar-wine-menu.php">Wine Menu</a> 

                        <a href="houston-wine-bar-happy-hour-menu.php">Happy Hour Menu</a> 

                        <a href="houston-wine-bar-food-menu.php">Food Menu</a> 

                        <a href="about-absolve-wine-lounge.php">About Us</a> 

                        <a href="houston-wine-bar-events.php">Events</a>

                        <a href="absolve-wine-lounge-photo-gallery.php">Gallery</a>

                        <a href="houston-wine-bar-contact.php" style="border-right:0px;">Contact Us</a>

                                           	

                     

            </div>

        </div>

	

 

    

    

    

    

	

	





</body>

</html>

