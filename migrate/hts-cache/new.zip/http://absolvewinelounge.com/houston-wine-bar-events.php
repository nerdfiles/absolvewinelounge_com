

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<title>Absolve Wine Lounge Events</title>
<meta name="keywords" content="Absolve Wine Lounge Events" />
<meta name="description" content="Absolve Wine Lounge Events" />
    <link href='http://fonts.googleapis.com/css?family=Alex+Brush' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Arbutus+Slab' rel='stylesheet' type='text/css'>
	<link href="css/style.css" rel="stylesheet" type="text/css" />
    <link href="css/nav-top.css" rel="stylesheet" type="text/css" />
    

	<script type="text/javascript" src="js/ie-hover-code.js"></script>
	<script type="text/javascript" src="js/prototype.js"></script>
    <script type="text/javascript" src="js/scriptaculous.js?load=effects,builder"></script>
    <style>
	#content-box{
	background:url(images/flourish3.jpg) top left no-repeat #FFFFFF;
	}
	
	</style>
      
</head>

	
<body>

	<div id="box">
		
		<div id="header">
		
			<a href="index.php"><img src="images/absolve-wine-lounge-logo.jpg" alt="Absolve Wine Lounge"/></a>
		
					
		</div>
				
		<div id="images-space"></div>
        
        <div id="navbar">
        	<div id="navbuttons">
					<ul id="nav-top">
						<li class="nav-top-tab"><a href="index.php">Home</a></li>

						<li class="nav-top-tab"><a href="houston-wine-bar-menu.php">Menu</a>
							<ul>
								<li><a href="houston-wine-bar-wine-menu.php">Wine</a></li>
								<li><a href="houston-wine-bar-happy-hour-menu.php">Happy Hour</a></li>
								<li><a href="houston-wine-bar-food-menu.php">Food</a></li>						
							</ul>
						</li>

						<li class="nav-top-tab"><a href="about-absolve-wine-lounge.php">About Us</a></li>

						<li class="nav-top-tab"><a href="houston-wine-bar-events.php" class="selected">Events</a></li>
                        
                        <li class="nav-top-tab"><a href="absolve-wine-lounge-photo-gallery.php">Gallery</a></li>
                        
                        <li class="nav-top-tab"><a href="houston-wine-bar-contact.php">Contact Us</a></li>
                        
					</ul>

				</div>
		</div>
		
      </div>  
        
        <div id="box2">
        
        
        
        
        <div id="content-box">
			
			
			
			
						
			
			
			<div id="content-wide">	

                                                                                                                                                            <h1>Absolve Wine Lounge Events</h1>  		                                  <br>          <p><span class="stylinMedium"><font size="7"><br></font></span></p><p><span class="stylinMedium"><font size="7"><br></font></span></p><p><span class="stylinMedium"><font size="7"><br></font></span></p><p><span class="stylinMedium"><font size="7">Live Music Fridays and Saturdays</font><br></span></p><br><p align="center"><font size="3"><span style="'color:"><font size="2"><font size="3"><span style="'color:"><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA"><br><br></span></span></span></font></font></span></font><font size="3"><span style="'color:"><font size="2"><font size="3"><span style="'color:"><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA">October 10th@9pm<br></span></span></span></font></font></span></font><font size="3"><span style="'color:"><font size="2"><font size="3"><span style="'color:"><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA"><font size="3"><span style="'color:"><font size="2"><font size="3"><span style="'color:"><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA">Jimmy K. Smith Jazz Trio<br></span></span></span></font></font></span></font></span></span></span></font></font></span></font><font size="3"><span style="'color:"><font size="2"><font size="3"><span style="'color:"><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA"><font size="3"><span style="'color:"><font size="2"><font size="3"><span style="'color:"><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA"><br>October 11th@9pm<br></span></span></span></font></font></span></font></span></span></span></font></font></span></font><font size="3"><span style="'color:"><font size="2"><font size="3"><span style="'color:"><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA"><font size="3"><span style="'color:"><font size="2"><font size="3"><span style="'color:"><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA"><font size="3"><span style="'color:"><font size="2"><font size="3"><span style="'color:"><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA">Dy'Lan Ashton Williams</span></span></span></font></font></span></font><font size="3"><span style="'color:"><font size="2"><font size="3"><span style="'color:"><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA"><font size="3"><span style="'color:"><font size="2"><font size="3"><span style="'color:"><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA"></span></span></span></font></font></span></font></span></span></span></font></font></span></font><br><br>October 17th@9pm<br>Mike Viteri Jazz<br><br>October 18th@9pm<br>Boodah's Painted Jazz Band<br><br></span></span></span></font></font></span></font></span></span></span></font></font></span></font><font size="3"><span style="'color:"><font size="2"><font size="3"><span style="'color:"><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA"><font size="3"><span style="'color:"><font size="2"><font size="3"><span style="'color:"><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA">October 24th@9pm</span></span></span></font></font></span></font></span></span></span></font></font></span></font><br><font size="3"><span style="'color:"><font size="2"><font size="3"><span style="'color:"><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA"><font size="3"><span style="'color:"><font size="2"><font size="3"><span style="'color:"><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA">Ben Jarrad</span></span></span></font></font></span></font></span></span></span></font></font></span></font><br><font size="3"><span style="'color:"><font size="2"><font size="3"><span style="'color:"><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA"><font size="3"><span style="'color:"><font size="2"><font size="3"><span style="'color:"><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA"><br></span></span></span></font></font></span></font></span></span></span></font></font></span></font><font size="3"><span style="'color:"><font size="2"><font size="3"><span style="'color:"><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA"><font size="3"><span style="'color:"><font size="2"><font size="3"><span style="'color:"><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA"><font size="3"><span style="'color:"><font size="2"><font size="3"><span style="'color:"><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA"><font size="3"><span style="'color:"><font size="2"><font size="3"><span style="'color:"><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA"><font size="3"><span style="'color:"><font size="2"><font size="3"><span style="'color:"><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA"><font size="3"><span style="'color:"><font size="2"><font size="3"><span style="'color:"><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA">October 31st@9pm-1am<br>Halloween!<br>Southern Backtones<br></span></span></span></font></font></span></font></span></span></span></font></font></span></font></span></span></span></font></font></span></font></span></span></span></font></font></span></font><br></span></span></span></font></font></span></font></span></span></span></font></font></span></font><br></p><p align="center"><font size="2"><br></font><br></p><div align="center"><span class="stylinMedium"><font size="7"></font></span><div align="left"><span class="stylinMedium"><br><font size="7">Wine Tastings</font></span><br></div></div><p><font size="2"><font size="3"><span style="'color:" rgb(121,="" 165,="" 77);="" font-family:="" optima;="" font-size:="" 20pt;="" mso-fareast-font-family:="" "arial="" unicode="" ms";="" mso-bidi-font-family:="" "lucida="" grande";="" mso-ansi-language:="" en-us;="" mso-fareast-language:="" mso-bidi-language:="" ar-sa;&#39;=""><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA">October Wine Tasting<br>October 23rd, 6-9pm... details soon to follow!<br></span></span></span></font></font></p><p><br><font size="2"><font size="3"><span style="'color:" rgb(121,="" 165,="" 77);="" font-family:="" optima;="" font-size:="" 20pt;="" mso-fareast-font-family:="" "arial="" unicode="" ms";="" mso-bidi-font-family:="" "lucida="" grande";="" mso-ansi-language:="" en-us;="" mso-fareast-language:="" mso-bidi-language:="" ar-sa;&#39;=""><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA"></span></span></span></font></font></p><p><br><font size="2"><font size="3"><span style="'color:" rgb(121,="" 165,="" 77);="" font-family:="" optima;="" font-size:="" 20pt;="" mso-fareast-font-family:="" "arial="" unicode="" ms";="" mso-bidi-font-family:="" "lucida="" grande";="" mso-ansi-language:="" en-us;="" mso-fareast-language:="" mso-bidi-language:="" ar-sa;&#39;=""><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA"></span></span></span></font></font></p><p><span class="stylinMedium"><font size="7">Second Sunday Cinema</font></span><br><font size="2"><font size="3"><span style="'color:" rgb(121,="" 165,="" 77);="" font-family:="" optima;="" font-size:="" 20pt;="" mso-fareast-font-family:="" "arial="" unicode="" ms";="" mso-bidi-font-family:="" "lucida="" grande";="" mso-ansi-language:="" en-us;="" mso-fareast-language:="" mso-bidi-language:="" ar-sa;&#39;=""><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA"></span></span></span></font></font></p><p><font size="2"><font size="3"><span style="'color:"><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA">The second Sunday of the month we're showing movies on our big screen with 20% off all bottles of wine and inexpensive bites for you to munch on while you watch the flick! This month were screening Bridget Jones's Diary.</span></span></span></font></font><br><font size="2"><font size="3"><span style="'color:" rgb(121,="" 165,="" 77);="" font-family:="" optima;="" font-size:="" 20pt;="" mso-fareast-font-family:="" "arial="" unicode="" ms";="" mso-bidi-font-family:="" "lucida="" grande";="" mso-ansi-language:="" en-us;="" mso-fareast-language:="" mso-bidi-language:="" ar-sa;&#39;=""><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA"></span></span></span></font></font></p><p><br><font size="2"><font size="3"><span style="'color:" rgb(121,="" 165,="" 77);="" font-family:="" optima;="" font-size:="" 20pt;="" mso-fareast-font-family:="" "arial="" unicode="" ms";="" mso-bidi-font-family:="" "lucida="" grande";="" mso-ansi-language:="" en-us;="" mso-fareast-language:="" mso-bidi-language:="" ar-sa;&#39;=""><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA"></span></span></span></font></font></p><p><font size="2"><font size="3"><span style="'color:" rgb(121,="" 165,="" 77);="" font-family:="" optima;="" font-size:="" 20pt;="" mso-fareast-font-family:="" "arial="" unicode="" ms";="" mso-bidi-font-family:="" "lucida="" grande";="" mso-ansi-language:="" en-us;="" mso-fareast-language:="" mso-bidi-language:="" ar-sa;&#39;=""><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA"></span></span></span></font></font><span class="stylinMedium"><br></span></p>  		<span class="stylinMedium"><font size="7">Private Events</font></span><p align="left"><font size="2"><span style="mso-bidi-font-weight:normal"><span style="font-size:14.0pt;font-family:&quot;Agency FB&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:  Times;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;  mso-fareast-language:EN-US;mso-bidi-language:AR-SA">Absolve Wine Lounge has space to book events for any occasion. Bridal showers, engagement parties, corporate events, holiday parties, and the list goes on for what Absolve can accomplish. We are happy to book events during and outside of our business hours. Contact our general manager, Courtney Wheeler at courtneywheeler@absolvewinelounge.com, by phone at 281.501.1788 or via the comment box on the 'Contact Us' page.</span></span></font><br>                                                                                                                                                                                                </p>                                                                                                                        

		

		<br style="clear:both;"/><br /><br />	

			

			</div>

		</div>

	


        

        </div>

        	<br style="clear:both;"/><br /><br />	

        <div id="box3">

            <div id="footer">

                

                

                

                    <a href="index.php">Home</a> 				

                        <a href="houston-wine-bar-wine-menu.php">Wine Menu</a> 

                        <a href="houston-wine-bar-happy-hour-menu.php">Happy Hour Menu</a> 

                        <a href="houston-wine-bar-food-menu.php">Food Menu</a> 

                        <a href="about-absolve-wine-lounge.php">About Us</a> 

                        <a href="houston-wine-bar-events.php">Events</a>

                        <a href="absolve-wine-lounge-photo-gallery.php">Gallery</a>

                        <a href="houston-wine-bar-contact.php" style="border-right:0px;">Contact Us</a>

                                           	

                     

            </div>

        </div>

	

 

    

    

    

    

	

	





</body>

</html>

