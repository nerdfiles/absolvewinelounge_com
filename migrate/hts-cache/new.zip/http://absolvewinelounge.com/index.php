





<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<title>Absolve Wine Lounge Home</title>
<meta name="keywords" content="Houston Wine Bar, Houston Wine Lounge, Wine Bar" />
<meta name="description" content="Changes are afoot at Absolve Wine Lounge. New food menu, new staff new management and a new energy in the bar. We want to welcome you to another phase in Absolve's history. 

Stop by on Friday and Saturday for live music!" />
	
    <link href='http://fonts.googleapis.com/css?family=Alex+Brush' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Arbutus+Slab' rel='stylesheet' type='text/css'><link href='http://fonts.googleapis.com/css?family=Montserrat+Alternates' rel='stylesheet' type='text/css'>
    
	<link href="css/style.css" rel="stylesheet" type="text/css" />
    <link href="css/nav-top.css" rel="stylesheet" type="text/css" />
    
    <link href="css/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="js/js-image-slider.js" type="text/javascript"></script>


	<script type="text/javascript" src="js/ie-hover-code.js"></script>
	<script type="text/javascript" src="js/prototype.js"></script>
    <script type="text/javascript" src="js/scriptaculous.js?load=effects,builder"></script>
    <style>
	#content-box{
	background:url(images/flourish0.jpg) top left no-repeat #FFFFFF;
	}
	
	
	</style>
      
      
    <script type="text/javascript" src="js/mobile.js"></script>  
</head>

	

<body>



	<div id="box">

		

		<div id="header">

		

			<a href="index.php"><img src="images/absolve-wine-lounge-logo.jpg" alt="Absolve Wine Lounge"/></a>

		

					

		</div>

				
		<div id="sliderFrame">
        <div id="slider">
            <img src="images/absolve-wine-lounge.jpg" />
            <img src="images/absolve-wine-lounge3.jpg" />
            <img src="images/absolve-wine-lounge2.jpg" />
            <img src="images/absolve-wine-lounge4.jpg" />
        </div>
        <div id="htmlcaption" style="display: none;">
        </div>
    </div>
		

		<!--<div id="images-space"></div>-->

        

        <div id="navbar">

        	<div id="navbuttons">

					<ul id="nav-top">

						<li class="nav-top-tab"><a href="index.php" class="selected">Home</a></li>



						<li class="nav-top-tab"><a href="houston-wine-bar-menu.php">Menu</a>

							<ul>

								<li><a href="houston-wine-bar-wine-menu.php">Wine</a></li>

								<li><a href="houston-wine-bar-happy-hour-menu.php">Happy Hour</a></li>

								<li><a href="houston-wine-bar-food-menu.php">Food</a></li>						

							</ul>

						</li>



						<li class="nav-top-tab"><a href="about-absolve-wine-lounge.php">About Us</a></li>



						<li class="nav-top-tab"><a href="houston-wine-bar-events.php">Events</a></li>

                        

                        <li class="nav-top-tab"><a href="absolve-wine-lounge-photo-gallery.php">Gallery</a></li>

                        

                        <li class="nav-top-tab"><a href="houston-wine-bar-contact.php">Contact Us</a></li>

                        

					</ul>



				</div>

		</div>

		

      </div>  

        

        <div id="box2">

        

        

        

        

        <div id="content-box">

			

			

			

			

			
			

			

			

			<div id="content-wide">	


                                                                                                                          <h1>Welcome to Absolve Wine Lounge</h1>  		          <p><br></p>                  <p>Changes are afoot at Absolve Wine Lounge. New food menu, new staff, new management and a new energy in the bar. We want to welcome you to another phase in Absolve's history. <br><br>Stop by on Friday and Saturday for live music or any day for a stellar glass of wine or the perfect bottle to capture your mood.<br><br><br><br><br></p><br><div align="center"><br></div><br>              <div style="width:350px;float:left;">            <p><span class="stylinLarge">Specials:</span></p>                      <p><span class="stylin">Mondays:</span>   ALL DAY Happy Hour<span style="margin-left:8px;"><br></span></p>          <br>  	            <p><span class="stylin">Tuesday � Friday:</span>   Happy Hour 4pm to 7pm</p>          <br>              <p><span class="stylin">Sundays:</span>&nbsp; 20% off ALL bottles<br></p>          <br>              <p><span class="stylin">Every day:</span> <font size="3" face="Times New Roman, Times, serif">25</font><font size="3"></font>% off all bottles purchased retail + 6 pack and case deals<br></p>          <br>  </div>              <div style="width:300px;float:left;">            <p><span class="stylinLarge">Hours of Operation:</span></p>                      <p style="margin-left: 10px;">Monday-Thursday: 4pm � 12am <br>Friday and Saturday: 4pm � 1am <br>Sunday: 4pm � 10pm <br></p><p style="margin-left: 10px;"><br></p><p style="margin-left: 10px;"><span class="stylinLarge">Events:&nbsp;</span><span style="margin-left: 8px;"><span class="stylinMedium"></span></span></p><p style="margin-left: 10px;"><span class="stylin"><br>Live Music <br>Every Friday and Saturday Night<br><br>October Wine Tasting<br><br>Second Sunday Cinema<br></span></p><br><p style="margin-left: 10px;"><span style="margin-left: 8px;">See our Events tab for more details<br></span></p>              </div>      <br style="clear:both;"><br>          <div align="left"><a href="https://www.facebook.com/pages/Absolve-Wine-Lounge/93051293042"><img src="images/upload/image-680.jpg" height="54" width="50"></a></div>            		                                                                                                                                                                                                                                    

		

		<br style="clear:both;"/><br /><br />	

			

			</div>

		</div>

	


        

        </div>

        	<br style="clear:both;"/><br /><br />	

        <div id="box3">

            <div id="footer">

                

                

                

                    <a href="index.php">Home</a> 				

                        <a href="houston-wine-bar-wine-menu.php">Wine Menu</a> 

                        <a href="houston-wine-bar-happy-hour-menu.php">Happy Hour Menu</a> 

                        <a href="houston-wine-bar-food-menu.php">Food Menu</a> 

                        <a href="about-absolve-wine-lounge.php">About Us</a> 

                        <a href="houston-wine-bar-events.php">Events</a>

                        <a href="absolve-wine-lounge-photo-gallery.php">Gallery</a>

                        <a href="houston-wine-bar-contact.php" style="border-right:0px;">Contact Us</a>

                                           	

                     

            </div>

        </div>

	

 

    

    

    

    

	

	





</body>

</html>

